<!DOCTYPE html>
<html>
<head>
	<title>Erro 404</title>
</head>
<body>

<h1><?php echo vita()->erroTitle; ?></h1>
<p><?php echo vita()->erroMessage; ?></p>

</body>
</html>
<?php

namespace Vita\System\Core\Database;

class QueryException extends DBException
{
}

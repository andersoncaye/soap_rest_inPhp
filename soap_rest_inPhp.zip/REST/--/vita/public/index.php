<?php

$ds = DIRECTORY_SEPARATOR;

require __DIR__ . "{$ds}..{$ds}src{$ds}Bootstrap.php";

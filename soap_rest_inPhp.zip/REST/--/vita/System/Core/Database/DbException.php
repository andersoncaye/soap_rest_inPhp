<?php

namespace Vita\System\Core\Database;

use \Vita\System\Core\Exception\VitaException;

class DbException extends VitaException
{
}

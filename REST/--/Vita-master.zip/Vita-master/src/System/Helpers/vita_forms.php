<?php 


function vita_form_crypt( &$val = null){
    return md5($val);
}

function vita_form_compare( &$val = null ){

}
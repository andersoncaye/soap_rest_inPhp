# Vita - PHP Framework

# [!]Importante - Vita está em Processo de Reestruturação, sistema estreamente instável e não usual

Vita é uma Framework PHP simples para fins didaticos e para criação de pequenos projetos. Utiliza TWIG como gerenciador de templates.

# Breve apresentação da Framework Vita

Vita é simples, pequena, fácil de entender e leve. É uma Framework PHP criada com intuitos didáticos a partir de uma coleção de classes PHP que funcionam como interface para gerenciar funções corriqueiramente do dia a dia na programação. Sendo assim, esconde a complexidade de alguma operações como Upload de Arquivos, Acesso a Base de dados, Controle de Erros, Logs, Sessões, entre outros. 
O objetivo principal desta framework é tornar mais rapido e amigável o processo de programar em linguagem PHP.

Por ser feita de um forma muito simples, sua base é de fácil compreenção mesmo para pessoas com pouco conhecimento de PHP.

Conta com muitos comentários entre os códigos que facilitam a identificação dos recursos e fluxo de funcionamento.

# Saiba mais

Ao extrair o Vita em seu servidor, use o navegador web para entrar na pasta vita/Manual. Existem inúmeros exemplos das classes e sobre a forma como usar o Vita.

Para saber mais sobre os trabalhos do autor acesse o site http://sooho.com.br

Autor: Wanderlei Santana <sans.pds@gmail.com>
Data: 2017.03.30 01:15h
Copyleft
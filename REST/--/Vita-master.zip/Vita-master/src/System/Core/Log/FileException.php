<?php

namespace Vita\System\Core\Log;

class FileException extends VitaException
{
}

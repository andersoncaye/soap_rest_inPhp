<?php

namespace Vita\System\Core\Database;

interface ProviderInterface
{
    public function conectar();
}
